react redux project template
=============

## Usage

Clone into desired directory and run 
```js
npm install
```

Now you can run
```js
npm start
```

and you will be able to view the output at: https://localhost:3002